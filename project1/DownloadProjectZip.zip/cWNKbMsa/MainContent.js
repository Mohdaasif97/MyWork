import React from "react"

export default function MainContent() {
    return (
        <div className="main">
            <h1>About</h1>
            <p>Hokage dattebayo</p>
            <p>Father of boruto uzumaki</p>
            <p>Husband of Hinata</p>

            <h2>Interest</h2>
            <p>Because of boruto naruto Uzumaki</p>
            <p>decided to became front end development</p>
            <p>Main Interest Is saaasake</p>
        </div>
    )

}