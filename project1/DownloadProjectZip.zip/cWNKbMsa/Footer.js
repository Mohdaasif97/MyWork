import react from "react"

export default function Footer() {

    return (

        <footer>
            <div className="footer">
                <img src="https://th.bing.com/th/id/OIP.LhL-bLYlFFjb4VkpoKDgsgHaHa?w=163&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" />
                <img src="https://th.bing.com/th/id/OIP.o06snWh5G4LQ1fJbNlarpAHaGB?w=250&h=203&c=7&r=0&o=5&dpr=1.3&pid=1.7" />
                <img src="https://th.bing.com/th/id/OIP.Qsl7ZlqntEmmCLXEnfxLOgHaHa?w=201&h=201&c=7&r=0&o=5&dpr=1.3&pid=1.7" />

            </div>

        </footer>
    )

}